#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# __init__.py
# Description: initialization file
# -----------------------------------------------------------------------------
#
# Login   <carlos.linares@uc3m.es>
#

"""
zipwatch init file
"""

__all__ = ["zwcschema"]


# Local Variables:
# mode:python
# fill-column:80
# End:
